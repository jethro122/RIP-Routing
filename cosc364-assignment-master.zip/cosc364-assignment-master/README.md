Cosc 364 assignment 1 Rip routing
