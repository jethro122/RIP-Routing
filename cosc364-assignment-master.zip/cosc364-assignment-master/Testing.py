from Rrouterfinal import *

table = {2: [2, 1, False, [0, 0]], 6: [
    6, 5, False, [0, 0]], 7: [7, 8, False, [0, 0]]}
port = 1
routerid = 1
data = [(2, 2, 2), [6, 1]]

print(readconfigfile('configtest1.txt'))
# print(readconfigfile('configtest2.txt'))
# print(readconfigfile('configtest3.txt'))
# print(readconfigfile('configtest4.txt'))
# print(readconfigfile('configtest5.txt'))
# print(readconfigfile('configtest6.txt'))
# print(readconfigfile('configtest7.txt'))

id, input, output = readconfigfile('configtest1.txt')

table = createroutingtable(output)

printtable(table, routerid)
